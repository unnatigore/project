import { Component } from '@angular/core';

@Component
({
    templateUrl: "./cart.component.html",
    styleUrls: ['./cart.component.css']
})
export class CartComponent
{
    
}