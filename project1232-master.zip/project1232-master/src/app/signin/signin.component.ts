import { Component } from '@angular/core';

@Component
({
    templateUrl: "./signin.component.html",
    styleUrls: ['./signin.component.css']
})
export class SigninComponent
{

}