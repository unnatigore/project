import { Component } from '@angular/core';

@Component
({
    templateUrl: "./signup.component.html",
    styleUrls: ['./signup.component.css']
})
export class SignupComponent
{

}